﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modication
{
    public class SalaryCalculator
    {
        public double CalculateBaseSalary(double hours, double rate)
        {
            return hours * rate;
        }

        public double CalculateNetSalary(double hours, double rate)
        {
            double gross = CalculateBaseSalary(hours, rate);
            double tax = gross * 0.13;
            return gross - tax;
        }
    }

    public class ModifiedSalaryCalculator : SalaryCalculator
    {
        public new double CalculateNetSalary(double hours, double rate, double bonus = 0)
        {
            double gross = CalculateBaseSalary(hours, rate);
            gross += bonus;
            double tax = 0;
            if (gross <= 25000)
                tax = gross * 0.10;
            else
                tax = 25000 * 0.10 + (gross - 25000) * 0.20;
            return gross - tax;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            SalaryCalculator oldCalc = new SalaryCalculator();
            double oldNet = oldCalc.CalculateNetSalary(160, 250);
            Console.WriteLine($"Старая версия (налог 13%): {oldNet}");

            ModifiedSalaryCalculator newCalc = new ModifiedSalaryCalculator();
            double newNet = newCalc.CalculateNetSalary(160, 250, 3000);
            Console.WriteLine($"Новая версия (с премией 3000): {newNet}");

            double noBonus = newCalc.CalculateNetSalary(160, 250);
            Console.WriteLine($"Новая версия (без премии): {noBonus}");
        }
    }
}